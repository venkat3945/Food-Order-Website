import React from 'react';
import { Link } from 'react-router-dom';
import img1 from '../Images/Screenshot 2022-07-12 122751.png';
import img2 from '../Images/Screenshot 2022-07-12 123528.png';
import img3 from '../Images/Screenshot 2022-07-12 125259.png';
import img4 from '../Images/Screenshot 2022-07-12 130502.png';
import img5 from '../Images/Screenshot 2022-07-12 131241.png';
import img6 from '../Images/Screenshot 2022-07-12 133957.png';
import img7 from '../Images/Screenshot 2022-07-12 134412.png';
import img8 from '../Images/Screenshot 2022-07-12 134901.png';

function Nav(){
  
  return(
    <div className='Nav'>
        <nav>
                    <div id="nav1">
                    <a id="nav11"><strong>HYDERABAD FOODS</strong></a>
                    <a><input type="text" placeholder="Search your food"></input></a>
                    <a>Location</a>
                    <a>Signin</a>
                    <a>Sign Up</a>
                    </div>
                </nav>
                    <div id="nav2">
                        <a id="nav21"><strong>65 restaurants Near you</strong></a>
                        <a>Relevance</a>
                        <a>Delivery</a>
                        <a>Rating</a>
                        <a>Offers</a>
                    </div>
      <div id="kf">
      <img src={img1} alt=""></img>
      <h3>Kruthangnya family</h3>
      <h5>Chinese, Indian, 3.5/5</h5> <p>$300 FOR TWO</p>
      </div>

      <div id="gbr">
        <Link to="/mutton"><img src={img2} alt=""></img></Link>
        <h3>Green Bawarchi Restaurant</h3>
        <h5>Biryani, Tandoor Chicken, Hyderabadi 3.5/5</h5><p>$200 FOR TWO</p>
      </div>

      <div id="pb">
        <Link to="/mutton"><img src={img3} alt=""></img></Link>
        <h3>Papadam's Blue</h3>
        <h5>Biryani, Chinese, Andhra, North Indian, South Indian, 4.0/5</h5><p>$500 FOR TWO</p>
        <h5></h5>
      </div>

      <div id="kfc">
        <Link to="/mutton"><img src={img4} alt=""></img></Link>
        <h3>KFC</h3>
        <h5>American, Snacks, Biryani, 3.8/5</h5><p>$400 FOR TWO</p>
      </div>

      <div id="bay">
        <Link to="/mutton"><img src={img5} alt=""></img></Link>
        <h3>Bay Leaf Restaurant</h3>
        <h5>North Indian, Biryani, Chinese, 3.5/5</h5><p>$300 FOR TWO</p>
      </div>

      <div id="bff">
        <Link to='/mutton'><img src={img6} alt=""></img></Link>
        <h3>Baarista Fast Food & Juice Center</h3>
        <h5>Chinese, 4.0/5</h5><p>$150 FOR TWO</p>
      </div>

      <div id="csi">
        <Link to="/mutton"><img src={img7}  alt=""></img></Link>
        <h3>Cream Stone Ice Cream</h3>
        <h5>Ice Cream, Deserts, Beverages, 4.2/5</h5><p>$250 FOR TWO</p>
      </div>

      <div id="pvr">
        <Link to="/mutton"><img src={img8} alt=""></img></Link>
        <h3>PVR Cafe</h3>
        <h5>Snacks, Fastfood, Beverages 4.3/5</h5><p>$400 FOR TWO</p>
      </div>
    </div>
  );
}

export default Nav;
